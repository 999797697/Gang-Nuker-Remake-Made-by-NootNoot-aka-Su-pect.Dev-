Discord Server: https://discord.gg/QFzy8ZS8sq
Owner: Su$pect.Dev/NootNoot
Developers: Su$pect.Dev/NootNoot , $GrimP



_________Support_________

If the nuker has any errors or wont run try this

Open cmd as admin , then type the commands that are listed below 1 by one

COMMANDS: pip install requests , pip install selenium , pip install bs4 , pip install colorama , pip install pycryptodome , pip install pypiwin32 , pip install PIL-Tools , pip install pylibcheck , pip install pyinstaller , pip install psutil , pip install keyboard , pip install httpx

If this dose not fix it then join the discord server and open a ticket Discord: https://discord.gg/QFzy8ZS8sq
